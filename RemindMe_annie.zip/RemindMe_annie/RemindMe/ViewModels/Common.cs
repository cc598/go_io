﻿namespace RemindMe.ViewModels
{
    class Common
    {
        public static string selectName = "";
        public static TodoItemViewModel ViewModel = new TodoItemViewModel();
    }
}
